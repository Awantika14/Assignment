# Databricks notebook source
# MAGIC %md
# MAGIC ## Ingest order.csv file

# COMMAND ----------

# MAGIC %md
# MAGIC ############ Step 1 - Read JSON file using the spark dataframe reader

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, LongType, DoubleType
from pyspark.sql.functions import input_file_name, current_timestamp

#  Define the schema for the Orders data
order_schema = StructType([
    StructField("Customer ID", StringType(), False),
    StructField("Discount", DoubleType(), False),
    StructField("Order Date", StringType(), False),
    StructField("Order ID", StringType(), False),
    StructField("Price", DoubleType(), False),
    StructField("Product ID", StringType(), False),
    StructField("Profit", DoubleType(), False),
    StructField("Quantity", LongType(), False),
    StructField("Row ID", LongType(), False),
    StructField("Ship Date", StringType(), False),
    StructField("Ship Mode", StringType(), False)
])

#  Read the Orders data from JSON with the predefined schema
order_raw_df = (
    spark.read
    .option("header", True)
    .option("multiLine", True)  # Handle multi-line JSON entries
    .schema(order_schema)
    .json("/FileStore/tables/Orders.json")
)

#  Perform basic data validation: column count, row count, schema check
print(f"Column Count: {len(order_raw_df.columns)}")
print(f"Row Count: {order_raw_df.count()}")
order_raw_df.printSchema()

#  Add metadata columns: source file name and ingestion timestamp
order_raw_df = (
    order_raw_df
    .withColumn("source_file", input_file_name())
    .withColumn("ingestion_time", current_timestamp())
)

# 5. Write the raw data as Parquet format
order_raw_df.write.format("parquet").mode("overwrite").saveAsTable("raw_order")
print("Order data successfully written in Parquet format.")
