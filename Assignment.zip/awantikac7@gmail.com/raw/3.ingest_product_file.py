# Databricks notebook source
# MAGIC %md
# MAGIC ## Ingest product file

# COMMAND ----------

# MAGIC %md
# MAGIC ############ Step 1 - Read CSV file using the spark dataframe reader

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType
from pyspark.sql.functions import input_file_name, current_timestamp

# 1️⃣ Define the schema for Product data
product_schema = StructType([
    StructField("Product ID", StringType(), False),
    StructField("Category", StringType(), False),
    StructField("Sub-Category", StringType(), False),
    StructField("Product Name", StringType(), False),
    StructField("State", StringType(), False),
    StructField("Price per product", StringType(), False)
])

# 2️⃣ Read the Product data from CSV with schema and options
product_raw_df = (
    spark.read
    .option("header", True)
    .option("multiLine", True)            # Support multiline CSV rows if any
    .option("escape", '"')                # Escape quotes properly
    .schema(product_schema)
    .csv("/FileStore/tables/Products.csv")
)

# 3️⃣ Perform basic data validation: column count, row count, schema check
print(f"Column Count: {len(product_raw_df.columns)}")
print(f"Row Count: {product_raw_df.count()}")
product_raw_df.printSchema()

# 4️⃣ Add metadata columns: source file name and ingestion timestamp
product_raw_df = (
    product_raw_df
    .withColumn("source_file", input_file_name())
    .withColumn("ingestion_time", current_timestamp())
)

# 5️⃣ Write the raw data as a Parquet-formatted table (raw layer)
product_raw_df.write.format("parquet").mode("overwrite").saveAsTable("raw_product")

print("✅ Product data successfully written to the 'raw_product' table.")

