# Databricks notebook source
# MAGIC %md
# MAGIC ## Ingest customer.csv file

# COMMAND ----------

# MAGIC %md
# MAGIC ############ Step 1 - Read CSV file using the spark dataframe reader

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType
from pyspark.sql.functions import input_file_name, current_timestamp

# 1. Define the schema for customer data
customer_schema = StructType([
    StructField("Customer ID", StringType(), False),
    StructField("Customer Name", StringType(), False),
    StructField("email", StringType(), False),
    StructField("phone", StringType(), False),
    StructField("address", StringType(), False),
    StructField("Segment", StringType(), False),
    StructField("Country", StringType(), False),
    StructField("City", StringType(), False),
    StructField("State", StringType(), False),
    StructField("Postal", StringType(), False),
    StructField("Region", StringType(), False)
])

# 2. Read customer data from CSV with predefined schema
customer_raw_df = (
    spark.read
    .option("header", True)
    .option("multiLine", True)
    .schema(customer_schema)
    .csv("/FileStore/tables/Customer.csv")
)

# 3. Validate the data (column count, row count, schema)
print(f"Column Count: {len(customer_raw_df.columns)}")
print(f"Row Count: {customer_raw_df.count()}")
customer_raw_df.printSchema()

# 4. Add metadata columns: source file name and ingestion timestamp
customer_raw_df = (
    customer_raw_df
    .withColumn("source_file", input_file_name())
    .withColumn("ingestion_time", current_timestamp())
)
# 5. Write the customer raw data as Parquet format
customer_raw_df.write.format("parquet").mode("overwrite").saveAsTable("raw_customer")
print("Customer data successfully written in Parquet format.")