# Databricks notebook source
#Quick verification
spark.sql("drop table if exists raw_customer purge")
dbutils.fs.rm("dbfs:/user/hive/warehouse/raw_customer",recurse=True)


spark.sql("drop table if exists raw_order purge")
dbutils.fs.rm("dbfs:/user/hive/warehouse/raw_order",recurse=True)



spark.sql("drop table if exists raw_product purge")
dbutils.fs.rm("dbfs:/user/hive/warehouse/raw_product",recurse=True)

# COMMAND ----------

# 🚀 Run all Raw Layer Notebooks
print("Starting Raw Layer Processing...")

%run ./raw/1.ingest_customer_file
%run ./raw/2.ingest_order_file

print("✅ Raw Layer Completed.")

# COMMAND ----------

# 🚀 Run all Processed Layer Notebooks
print("Starting Processed Layer Processing...")

%run ./processed/1.processed_customer_table
%run ./processed/2.processed_order_table
%run ./processed/3.processed_product_table

print("✅ Processed Layer Completed.")

# COMMAND ----------

# 🚀 Run all Enriched Layer Notebooks
print("Starting Enriched Layer Processing...")

%run ./enriched/1.enriched_orders_table

print("✅ Enriched Layer Completed.")
