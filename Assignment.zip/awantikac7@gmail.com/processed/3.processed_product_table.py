# Databricks notebook source
# MAGIC %md
# MAGIC ## Process product file

# COMMAND ----------

# MAGIC %md
# MAGIC Clean the raw data

# COMMAND ----------

from pyspark.sql.functions import col, rtrim, ltrim, trim
from pyspark.sql.types import DoubleType

# COMMAND ----------

#  Read the raw product Delta table
product_df = spark.table("raw_product")

#  Data validation at the start of processing
print(f" Column Count (before cleaning): {len(product_df.columns)}")
print(f" Row Count (before cleaning): {product_df.count()}")
product_df.printSchema()

# COMMAND ----------


#  Clean column names (snake_case, no spaces/special chars)
product_df = product_df.toDF(*[
    c.strip().lower().replace(" ", "_").replace("-", "_") for c in product_df.columns
])

#  Trim whitespace from all string columns
for c in product_df.columns:
    if dict(product_df.dtypes)[c] == 'string':
        product_df = product_df.withColumn(c, trim(rtrim(ltrim(col(c)))))

#  Handle data types (e.g., price_per_product column)
product_df = product_df.withColumn(
    "price_per_product", col("price_per_product").cast(DoubleType())
)

# Select and reorder columns for processed table
product_df = product_df.select(
    "product_id", "category", "sub_category", "product_name",
    "state", "price_per_product", "source_file", "ingestion_time"
)

#  Write the processed product table in Delta format
product_df.write.format("delta").mode("overwrite").option("mergeSchema", True).saveAsTable("processed_product")
print(" Processed product table saved as Delta table: processed_product")




# COMMAND ----------


#  Final data validation after cleaning
print(f" Column Count (after cleaning): {len(product_df.columns)}")
print(f" Row Count (after cleaning): {product_df.count()}")
product_df.printSchema()
