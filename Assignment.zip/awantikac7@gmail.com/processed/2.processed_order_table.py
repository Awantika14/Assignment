# Databricks notebook source
# MAGIC %md
# MAGIC ## Process order.csv file

# COMMAND ----------

# MAGIC %md
# MAGIC ############ Step 1 - Read table using the spark dataframe reader

# COMMAND ----------

from pyspark.sql.functions import length,col,count,rtrim,ltrim,trim,lower,upper,cast,to_date,round

# COMMAND ----------

#read the raw order table

order_df= spark.table("raw_order")
# data validation at processed time
print(f"Column Count: {len(order_df.columns)}")

#row count at process time
print(f"Row Count: {order_df.count()}")

#schema check
order_df.printSchema()  
display(order_df)

# COMMAND ----------

# MAGIC %md
# MAGIC Clean the raw data

# COMMAND ----------

#clean the column names to store in the delta format
order_df= order_df.toDF(*[c.strip().lower().replace(" ","_") for c in order_df.columns])

# trim blank spaces from all the columns field values
for c in order_df.columns:
    if dict(order_df.dtypes)[c]== 'string':
        order_df=order_df.withColumn(c,rtrim(ltrim(col(c))))

#manage data types of columns
order_df= order_df.withColumn(
    "order_date_cast",to_date(col("order_date"),'d/m/yyyy')).withColumn(
    "ship_date_cast",to_date(col("ship_date"),'d/m/yyyy')).withColumn(
        "profit_rounded",round(col("profit"),2)).drop(
            "ship_date","order_date","profit").withColumnRenamed(
                "order_date_cast","order_date").withColumnRenamed(
                    "ship_date_cast","ship_date").withColumnRenamed(
                        "profit_rounded","profit")

order_df=order_df.select("customer_id","discount","order_date","order_id","price","product_id","profit","quantity","row_id","ship_date","ship_mode","source_file","ingestion_time")

display(order_df)

# COMMAND ----------

order_df.write.format("delta").mode("overwrite").option("mergeSchema",True).saveAsTable("processed_order")
# data validation at cleaning
print(f"Column Count: {len(order_df.columns)}")

#row count at cleaning
print(f"Row Count: {order_df.count()}")

#schema check
#customercleaned_df.printSchema()

# COMMAND ----------

# Final data validation: Column count, row count
print(f"Column Count: {len(order_df.columns)}")
print(f"Row Count: {order_df.count()}")

# Data validation: Null checks for critical columns
critical_columns = ["customer_id", "order_id", "product_id", "order_date"]
for col_name in critical_columns:
    null_count = order_df.filter(col(col_name).isNull()).count()
    print(f"Nulls in '{col_name}': {null_count}")

# Duplicate check for order_id
duplicate_count = order_df.groupBy("order_id").count().filter(col("count") > 1).count()
print(f"Duplicate 'order_id' entries: {duplicate_count}")

# Format check: Ensure 'order_date' and 'ship_date' are valid dates
invalid_order_dates = order_df.filter(col("order_date").isNull()).count()
invalid_ship_dates = order_df.filter(col("ship_date").isNull()).count()
print(f"Invalid 'order_date' entries: {invalid_order_dates}")
print(f"Invalid 'ship_date' entries: {invalid_ship_dates}")

# Numeric format check: Profit should not have more than 2 decimals
invalid_profit = order_df.filter((col("profit") != round(col("profit"), 2))).count()
print(f"Profit values not rounded to 2 decimal places: {invalid_profit}")
