# Databricks notebook source
# MAGIC %md
# MAGIC ## Process raw customer table

# COMMAND ----------

# MAGIC %md
# MAGIC ############ Step 1 - Read CSV file using the spark dataframe reader

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, LongType
from pyspark.sql.functions import (
    regexp_replace, col, regexp_extract, rtrim, ltrim, trim, lower, udf, current_timestamp, input_file_name
)

# COMMAND ----------


# Read raw customer data from the 'raw_customer' table
customer_df = spark.table("raw_customer")

# Data validation at the start of processing
print(f"Column Count: {len(customer_df.columns)}")
print(f"Row Count: {customer_df.count()}")
customer_df.printSchema()

# COMMAND ----------


# Clean column names: Convert to snake_case (lowercase + underscores)
customer_df = customer_df.toDF(*[
    c.strip().lower().replace(" ", "_") for c in customer_df.columns
])

# Trim leading and trailing spaces from all string columns
for c in customer_df.columns:
    if dict(customer_df.dtypes)[c] == 'string':
        customer_df = customer_df.withColumn(c, rtrim(ltrim(col(c))))

# Clean phone number and extract extension
customercleaned_df = (
    customer_df
    .withColumn("clean_phone", regexp_replace(col("phone"), r"x(\d+)", ""))  # Remove extension from phone
    .withColumn("extension", regexp_extract(col("phone"), r"x(\d+)", 1).cast("long"))  # Extract extension
)

# UDF to replace digits in customer names with letters (e.g., 0 → o, 1 → l)
def replace_digits_in_name(name):
    if name is None:
        return None
    replacements = {'0': 'o', '1': 'l', '3': 'e', '4': 'a', '5': 's', '7': 't'}
    for digit, letter in replacements.items():
        name = name.replace(digit, letter)
    return name

replace_digits_udf = udf(replace_digits_in_name, StringType())

# UDF to uppercase the prefix in customer_id (e.g., abc-123 → ABC-123)
def uppercase_prefix(cust_id):
    if cust_id and "-" in cust_id:
        prefix, suffix = cust_id.split("-", 1)
        return f"{prefix.upper()}-{suffix}"
    return cust_id

uppercase_prefix_udf = udf(uppercase_prefix, StringType())

# Further data cleaning
customercleaned_df = (
    customercleaned_df
    .withColumn("clean_phones", regexp_replace(col("clean_phone"), r"[^0-9]", "").cast("long"))  # Keep only digits in phone
    .withColumn("customer_name_cleaned",
        trim(
            regexp_replace(
                regexp_replace(replace_digits_udf(col("customer_name")), r"[^A-Za-z\s]", ""),  # Remove special chars
                r"\s+", " "  # Collapse multiple spaces
            )
        )
    )
    .withColumn("email_cleaned", lower(trim(col("email"))))  # Lowercase email
    .withColumn("customer_id_cleaned", uppercase_prefix_udf(col("customer_id")))  # Uppercase prefix in customer_id
    .withColumn("address_cleaned",
        trim(
            regexp_replace(
                regexp_replace(col("address"), r"[\r\n]+", " "),  # Remove newlines
                r"\s+", " "  # Collapse multiple spaces
            )
        )
    )
)

# Drop unwanted columns and rename cleaned columns
customercleaned_df = (
    customercleaned_df
    .drop("phone", "clean_phone", "customer_name", "customer_id", "email", "address")
    .withColumnRenamed("clean_phones", "phone")
    .withColumnRenamed("customer_name_cleaned", "customer_name")
    .withColumnRenamed("email_cleaned", "email")
    .withColumnRenamed("customer_id_cleaned", "customer_id")
    .withColumnRenamed("address_cleaned", "address")
    .select(
        "customer_id", "customer_name", "email", "phone", "extension",
        "address", "segment", "country", "city", "state", "postal",
        "region", "source_file", "ingestion_time"
    )
)

# Display processed data
display(customercleaned_df)

# Write the processed data to Delta table 'processed_customer'
customercleaned_df.write.format("delta").mode("overwrite").option("mergeSchema", True).saveAsTable("processed_customer")
print("✅ Processed customer data written to 'processed_customer' table.")



# COMMAND ----------

# Final Data Validation Checks
print(f"Column Count: {len(customercleaned_df.columns)}")
print(f"Row Count: {customercleaned_df.count()}")

# Null checks for critical columns
critical_columns = ["customer_id", "customer_name", "email", "phone"]
for col_name in critical_columns:
    null_count = customercleaned_df.filter(col(col_name).isNull()).count()
    print(f"Nulls in '{col_name}': {null_count}")

# Duplicate check for customer_id
duplicate_count = customercleaned_df.groupBy("customer_id").count().filter(col("count") > 1).count()
print(f"Duplicate 'customer_id' entries: {duplicate_count}")

# Format checks (example: emails containing '@' and phone numbers with 10 digits)
invalid_email_count = customercleaned_df.filter(~col("email").contains("@")).count()
print(f"Invalid emails (missing '@'): {invalid_email_count}")

invalid_phone_count = customercleaned_df.filter(col("phone").isNotNull() & (col("phone").cast("string").rlike("^[0-9]{10}$") == False)).count()
print(f"Invalid phone numbers (not 10 digits): {invalid_phone_count}")
