# Databricks notebook source
# MAGIC %md
# MAGIC ## Emriched order and product table

# COMMAND ----------

# MAGIC %md
# MAGIC ############ Step 1 - Read table using the spark dataframe reader

# COMMAND ----------

from pyspark.sql.functions import (
    col, round as spark_round, current_timestamp, year, sum as spark_sum, trim, rtrim, ltrim
)

# COMMAND ----------

# Load processed tables
product_df = spark.table("processed_product")
order_df = spark.table("processed_order")
customer_df = spark.table("processed_customer")

# Rename ambiguous column in product table
product_df = product_df.withColumnRenamed("state", "product_state")

# Create Enriched Orders table by joining customer, order, and product data
enriched_orders_df = (
    order_df.join(customer_df, on="customer_id", how="left")
            .join(product_df, on="product_id", how="left")
            .withColumn("order_year", year(col("order_date")))
            .withColumn("processed_time", current_timestamp())
            .select(
                "order_id", "order_date", "order_year",
                "customer_id", "customer_name", "country",
                "product_id", "category", "sub_category", "profit"
            )
)

# Data validation: Enriched Orders table
print(f"Column Count: {len(enriched_orders_df.columns)}")
print(f"Row Count: {enriched_orders_df.count()}")
enriched_orders_df.printSchema()

# Write Enriched Orders table partitioned by country
enriched_orders_df.write.format("delta").mode("overwrite").option("mergeSchema", True).partitionBy("country").saveAsTable("table_enriched_order")

# COMMAND ----------

# Create Customer Profit Summary table
enriched_df = (
    enriched_orders_df
    .select(
        "customer_id", "customer_name", "country",
        "category", "sub_category", spark_round(col("profit"), 2).alias("profit")
    )
    .distinct()
)


# Data validation: Customer Profit table
print(f"Column Count: {len(enriched_df.columns)}")
print(f"Row Count: {enriched_df.count()}")
enriched_df.printSchema()

# Write Customer Profit table partitioned by country
enriched_df.write.format("delta").mode("overwrite").option("mergeSchema", True).partitionBy("country").saveAsTable("table_customer_profit")

# COMMAND ----------

# Create Aggregate Profit table by year, category, sub-category, and customer
aggregate_df = (
    enriched_orders_df
    .groupBy("order_year", "category", "sub_category", "customer_name")
    .agg(spark_sum("profit").alias("profit"))
)

# Data validation: Aggregate Profit table
print(f"Column Count: {len(aggregate_df.columns)}")
print(f"Row Count: {aggregate_df.count()}")
aggregate_df.printSchema()

# Write Aggregate Profit table partitioned by order year
aggregate_df.write.format("delta").mode("overwrite").option("mergeSchema", True).partitionBy("order_year").saveAsTable("table_agg_profit")
