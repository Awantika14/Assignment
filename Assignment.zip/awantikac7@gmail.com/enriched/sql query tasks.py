# Databricks notebook source
# MAGIC %md
# MAGIC 1. Using SQL output the following aggregates
# MAGIC Profit by Year
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT 
# MAGIC order_year as Year,
# MAGIC round(SUM(profit),2) as Profit
# MAGIC FROM table_enriched_order
# MAGIC group by order_year;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC 2. Using SQL output the following aggregates Profit by Year + Product Category

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT 
# MAGIC order_year as Year,
# MAGIC category,
# MAGIC round(SUM(profit),2) as Profit
# MAGIC FROM table_enriched_order
# MAGIC where  category is NOT NULL
# MAGIC group by order_year,category;

# COMMAND ----------

# MAGIC %md
# MAGIC 3. Using SQL output the following aggregates Profit by Customer

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT 
# MAGIC customer_name as Customer,
# MAGIC round(SUM(profit),2) as Profit
# MAGIC FROM table_enriched_order
# MAGIC group by customer_name;

# COMMAND ----------

# MAGIC %md
# MAGIC 4. Using SQL output the following aggregates Profit by Customer + Year

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT 
# MAGIC customer_name as Customer,
# MAGIC order_year as Year,
# MAGIC round(SUM(profit),2) as Profit
# MAGIC FROM table_enriched_order
# MAGIC group by customer_name,order_year;