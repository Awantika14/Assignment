# Databricks notebook source
# MAGIC %md
# MAGIC Unit Test Class

# COMMAND ----------

import unittest
import builtins
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, round as spark_round

# Initialize SparkSession
spark = SparkSession.builder.appName("DataPipelineTest").getOrCreate()

# Function to load raw data from files
def load_raw_data(spark):
    """
    Load raw data from source files into DataFrames.
    Returns: customer_df, product_df, order_df
    """
    customer_df = spark.read.option("header", True).csv("/FileStore/tables/Customer.csv")
    product_df = spark.read.option("header", True).csv("/FileStore/tables/Products.csv")
    order_df = spark.read.option("multiline", True).json("/FileStore/tables/Orders.json")
    return customer_df, product_df, order_df

# Function to process data: rename columns, round profit
def process_data(order_df):
    """
    Process the raw orders DataFrame:
    - Rename columns to snake_case
    - Round profit column to 2 decimal places
    """
    return order_df \
        .withColumnRenamed("Order ID", "order_id") \
        .withColumnRenamed("Customer ID", "customer_id") \
        .withColumnRenamed("Product ID", "product_id") \
        .withColumnRenamed("Product Name", "product_name") \
        .withColumnRenamed("Profit", "profit") \
        .withColumnRenamed("Order Date", "order_date") \
        .withColumn("profit", spark_round(col("profit"), 2))

# Function to enrich data: join customers and products with orders
def enrich_data(order_df, customer_df, product_df):
    """
    Enrich processed orders by joining:
    - Customer data on 'customer_id'
    - Product data on 'product_id'
    """
    # Rename columns in customer and product DataFrames
    customer_df = customer_df \
        .withColumnRenamed("Customer ID", "customer_id") \
        .withColumnRenamed("Customer Name", "customer_name")
    
    product_df = product_df \
        .withColumnRenamed("Product ID", "product_id") \
        .withColumnRenamed("Category", "category") \
        .withColumnRenamed("Sub-Category", "sub_category")
    
    # Perform the joins
    return order_df.join(customer_df, on="customer_id", how="left") \
                   .join(product_df, on="product_id", how="left")

# Unit test class using unittest framework
class TestDataPipeline(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        # Setup Spark session for tests
        cls.spark = spark

    # Test raw data file loading
    def test_load_raw_data(self):
        customer_df, product_df, order_df = load_raw_data(self.spark)
        self.assertGreater(customer_df.count(), 0)
        self.assertGreater(product_df.count(), 0)
        self.assertGreater(order_df.count(), 0)

    # Test presence of critical columns in raw data
    def test_raw_schema_validation(self):
        customer_df, product_df, order_df = load_raw_data(self.spark)
        self.assertIn("Customer ID", customer_df.columns)
        self.assertIn("Product ID", product_df.columns)
        self.assertIn("Order ID", order_df.columns)

    # Test null handling in critical columns
    def test_raw_null_handling(self):
        customer_df, product_df, order_df = load_raw_data(self.spark)
        self.assertEqual(customer_df.filter(col("Customer ID").isNull()).count(), 0)
        self.assertEqual(product_df.filter(col("Product ID").isNull()).count(), 0)
        self.assertEqual(order_df.filter(col("Order ID").isNull()).count(), 0)

    # Test duplicate detection in orders
    def test_raw_duplicate_detection(self):
        _, _, order_df = load_raw_data(self.spark)
        duplicates = order_df.groupBy("Order ID").count().filter(col("count") > 1).count()
        self.assertGreaterEqual(duplicates, 0)  # Allow for no duplicates

    # Test profit rounding correctness
    def test_profit_rounding(self):
        _, _, order_df = load_raw_data(self.spark)
        processed_df = process_data(order_df)
        profits = processed_df.select("profit").limit(10).collect()
        for row in profits:
            if row.profit is not None:
                self.assertEqual(builtins.round(float(row.profit), 2), float(row.profit))

    # Test handling of negative, zero, and null profit values
    def test_profit_negative_zero_null(self):
        _, _, order_df = load_raw_data(self.spark)
        processed_df = process_data(order_df)
        negative = processed_df.filter(col("profit") < 0).count()
        zeros = processed_df.filter(col("profit") == 0).count()
        nulls = processed_df.filter(col("profit").isNull()).count()
        self.assertGreaterEqual(negative, 0)
        self.assertGreaterEqual(zeros, 0)
        self.assertGreaterEqual(nulls, 0)

    # Test join integrity: required columns present after join
    def test_join_integrity(self):
        customer_df, product_df, order_df = load_raw_data(self.spark)
        processed_df = process_data(order_df)
        enriched_df = enrich_data(processed_df, customer_df, product_df)
        self.assertIn("customer_name", enriched_df.columns)
        self.assertIn("category", enriched_df.columns)
        self.assertIn("sub_category", enriched_df.columns)

    # Test null handling in enriched layer joins
    def test_enriched_nulls_in_joins(self):
        customer_df, product_df, order_df = load_raw_data(self.spark)
        processed_df = process_data(order_df)
        enriched_df = enrich_data(processed_df, customer_df, product_df)
        null_customers = enriched_df.filter(col("customer_name").isNull()).count()
        null_categories = enriched_df.filter(col("category").isNull()).count()
        null_sub_categories = enriched_df.filter(col("sub_category").isNull()).count()
        self.assertGreaterEqual(null_customers, 0)
        self.assertGreaterEqual(null_categories, 0)
        self.assertGreaterEqual(null_sub_categories, 0)

    # Test row count consistency after joins
    def test_enriched_row_count_consistency(self):
        customer_df, product_df, order_df = load_raw_data(self.spark)
        processed_df = process_data(order_df)
        enriched_df = enrich_data(processed_df, customer_df, product_df)
        self.assertEqual(
            enriched_df.select("order_id").distinct().count(),
            processed_df.select("order_id").distinct().count()
        )

    # Test handling of empty DataFrames (mock test)
    def test_empty_file_handling(self):
        try:
            empty_df = self.spark.createDataFrame([], "id STRING")
            self.assertEqual(empty_df.count(), 0)
        except Exception:
            self.fail("Empty DataFrame handling failed")


# COMMAND ----------

# MAGIC %md
# MAGIC Run Tests

# COMMAND ----------

# Run the unit test suite when this script is executed
if __name__ == "__main__":
    # unittest.main() is the standard way to run unit tests in Python.
    # In Databricks or Jupyter notebooks, we need to tweak arguments:
    # - argv=['']: Avoids passing notebook arguments to unittest (which can cause errors).
    # - verbosity=2: Enables detailed test output (test names, status).
    # - exit=False: Prevents unittest from calling sys.exit(), which is necessary in notebooks.
    unittest.main(argv=[''], verbosity=2, exit=False)
